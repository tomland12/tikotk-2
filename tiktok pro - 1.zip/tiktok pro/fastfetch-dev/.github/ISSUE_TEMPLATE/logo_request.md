---
name: Logo request
about: Request a new logo
title: '[LOGO] '
labels: logo request
assignees: ''

---

Tip: A logo can be displayed by fastfetch without getting into fastfetch's official repo. For highly customized logo for personal use, it's recommended to keep it locally. Please refer to https://github.com/fastfetch-cli/fastfetch/wiki/Migrate-Neofetch-Logo-To-Fastfetch

# OS
```
Paste content of /etc/os-release here. If this file doesn't exist, describe a way to identify the distro.
```

# Ascii
```
Paste ascii art here.
```
