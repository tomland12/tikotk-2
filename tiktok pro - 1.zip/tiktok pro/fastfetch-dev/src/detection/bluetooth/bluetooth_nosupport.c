#include "bluetooth.h"

const char* ffDetectBluetooth(FF_MAYBE_UNUSED FFlist* devices /* FFBluetoothResult */)
{
    return "Not supported on this platform";
}
