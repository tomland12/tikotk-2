#include "board.h"

const char* ffDetectBoard(FF_MAYBE_UNUSED FFBoardResult* board)
{
    return "Not supported on this platform";
}
