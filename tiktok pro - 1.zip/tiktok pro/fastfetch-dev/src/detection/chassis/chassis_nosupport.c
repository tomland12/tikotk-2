#include "chassis.h"

const char* ffDetectChassis(FF_MAYBE_UNUSED FFChassisResult* result)
{
    return "Not supported on this platform";
}
