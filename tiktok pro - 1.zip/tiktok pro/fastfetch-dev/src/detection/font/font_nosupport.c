#include "fastfetch.h"
#include "font.h"

const char* ffDetectFontImpl(FF_MAYBE_UNUSED FFFontResult* result)
{
    FF_UNUSED(result);
    return "Not supported on this platform";
}
