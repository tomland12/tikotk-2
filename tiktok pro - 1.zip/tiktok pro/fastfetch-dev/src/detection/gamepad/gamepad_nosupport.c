#include "gamepad.h"

const char* ffDetectGamepad(FF_MAYBE_UNUSED FFlist* devices /* List of FFGamepadDevice */)
{
    return "Not supported on this platform";
}
