#pragma once

#include "fastfetch.h"

const char* ffDetectIcons(FFstrbuf* result);
