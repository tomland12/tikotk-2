#include "icons.h"

const char* ffDetectIcons(FF_MAYBE_UNUSED FFstrbuf* result)
{
    return "Not supported on this platform";
}
