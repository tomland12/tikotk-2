#include "lm.h"

const char* ffDetectLM(FF_MAYBE_UNUSED FFLMResult* result)
{
    return "Not supported on this platform";
}
