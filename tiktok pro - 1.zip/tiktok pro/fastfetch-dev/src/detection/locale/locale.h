#pragma once

#include "fastfetch.h"

void ffDetectLocale(FFstrbuf* result);
