#include "monitor.h"

const char* ffDetectMonitor(FF_MAYBE_UNUSED FFlist* results)
{
    return "Not supported on this platform";
}
