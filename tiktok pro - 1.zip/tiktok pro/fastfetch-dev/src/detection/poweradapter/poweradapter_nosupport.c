#include "poweradapter.h"

const char* ffDetectPowerAdapter(FF_MAYBE_UNUSED FFlist* results)
{
    return "Not supported on this platform";
}
