#pragma once

#include "fastfetch.h"

const char* ffDetectProcesses(uint32_t* result);
