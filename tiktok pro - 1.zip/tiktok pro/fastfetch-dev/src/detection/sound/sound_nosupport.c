#include "sound.h"

const char* ffDetectSound(FF_MAYBE_UNUSED FFlist* devices /* List of FFSoundDevice */)
{
    return "Not supported on this platform";
}
