#pragma once

const char* ffDetectCpuTemp(double* current);
const char* ffDetectThermalTemp(double* current);
