#pragma once

const char* ffDetectSmbiosTemp(double* current, double* critical);
