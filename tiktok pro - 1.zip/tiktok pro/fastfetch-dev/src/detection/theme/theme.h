#pragma once

#include "fastfetch.h"

const char* ffDetectTheme(FFstrbuf* result);
