#include "theme.h"

const char* ffDetectTheme(FF_MAYBE_UNUSED FFstrbuf* result)
{
    return "Not supported on this platform";
}
