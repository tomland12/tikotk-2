#pragma once

#include "fastfetch.h"

const char* ffDetectWallpaper(FFstrbuf* result);
