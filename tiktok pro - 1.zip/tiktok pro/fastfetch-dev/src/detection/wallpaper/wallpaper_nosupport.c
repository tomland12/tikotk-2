#include "wallpaper.h"

const char* ffDetectWallpaper(FF_MAYBE_UNUSED FFstrbuf* result)
{
    return "Not supported on this platform";
}
