#pragma once

#include "fastfetch.h"

const char* ffDetectWMPlugin(FFstrbuf* pluginName);
