#pragma once

#ifndef FASTFETCH_INCLUDED_detection_wmtheme
#define FASTFETCH_INCLUDED_detection_wmtheme

#include "fastfetch.h"

bool ffDetectWmTheme(FFstrbuf* themeOrError);

#endif
